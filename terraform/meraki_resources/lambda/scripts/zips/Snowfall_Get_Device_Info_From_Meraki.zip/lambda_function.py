
import requests
import re
import json
import boto3 

nextToken = ''

def merakiAPI():
    authToken = 'Bearer be61b5c7528a4cb0b67f7b531e1070476482de2e'
    global nextToken

    url = "https://api.meraki.com/api/v1/organizations/662029145223463867/devices"
    payload = {'perPage': '1000',
    'startingAfter': nextToken}
    files=[]
    headers = {
      'Authorization': authToken
    }
    response = requests.request("GET", url, headers=headers, data=payload, files=files)

    links = response.headers.get('Link').split(', ')
    nextToken = None
    for link in links:
        if 'rel=next' in link:
            # Extract the URL part
            url = link.split(';')[0].strip('<>')

            # Use regex to extract the value of 'startingAfter'
            match = re.search(r'startingAfter=([^&]+)', url)
            if match:
                nextToken = match.group(1)
                break
   
    return response
    

def lambda_handler(event, context):
    deviceList = []

    #Run the API until all devices retrived
    while nextToken != None:
        response = merakiAPI()
        devices = response.json()
        for device in devices:
            #print(device)
            deviceList.append({
                "device_name": device.get("name"),
                "model": device.get("model"),
                "serial": device.get("serial"),
                "firmware": device.get("firmware"),
            })
            

    #print (deviceList)


    # Convert the list to JSON
    json_data = json.dumps(deviceList, indent=4)

    # Initialize S3 client
    s3_client = boto3.client('s3')

    from datetime import datetime
    current_time = datetime.now()
    filename = 'device_list_' + current_time.strftime("%Y-%m-%d_%H-%M-%S") + '.json'

    # Define the bucket name and the S3 file path (key)
    bucket_name = 'snowfall-dev-meraki-landing'
    s3_key = 'meraki/' + filename  # Modify the path as needed

    # Upload JSON data to S3
    try:
        # Using `put_object` to upload the JSON directly from a string
        s3_client.put_object(Body=json_data, Bucket=bucket_name, Key=s3_key)
        print(f"Data successfully uploaded to s3://{bucket_name}/{s3_key}")
    except Exception as e:
        print(f"Error uploading data to S3: {e}")
