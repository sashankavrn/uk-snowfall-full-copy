import boto3
import json
import requests
import time
from datetime import datetime

# Initialize boto3 clients
dynamodb = boto3.resource('dynamodb')
athena = boto3.client('athena')

# DynamoDB tables
RULES_TABLE = "incident_rules"
TICKETS_TABLE = "service_now_tickets"

# Athena config
ATHENA_DB = "your_athena_database"
ATHENA_OUTPUT = "s3://your-athena-query-results/"

# ServiceNow API config (will come from IT team)
SERVICENOW_URL = "https://your-instance.service-now.com/api/now/table/incident"
SERVICENOW_USER = "your-username"
SERVICENOW_PASS = "your-password"

def lambda_handler(event, context):
    # Step 1: Fetch rules from DynamoDB
    rules_table = dynamodb.Table(RULES_TABLE)
    rules_response = rules_table.scan()
    rules = rules_response.get("Items", [])

    for rule in rules:
        rule_id = rule["rule_id"]
        query = rule["athena_query"]
        threshold = int(rule["threshold"])

        print(f"Processing Rule: {rule_id}")

        # Step 2: Run Athena Query
        result_count = run_athena_query(query)

        if result_count >= threshold:
            print(f"Threshold breached: {result_count} >= {threshold}")

            # Step 3: Check if incident already exists
            tickets_table = dynamodb.Table(TICKETS_TABLE)
            existing_ticket = tickets_table.get_item(Key={"rule_id": rule_id})

            if "Item" in existing_ticket:
                print(f"Incident already exists for rule {rule_id}, skipping.")
                continue

            # Step 4: Create ServiceNow Incident
            incident_id = create_service_now_ticket(rule, result_count)

            if incident_id:
                # Save ticket info in DynamoDB
                tickets_table.put_item(Item={
                    "rule_id": rule_id,
                    "incident_id": incident_id,
                    "created_at": datetime.utcnow().isoformat(),
                    "status": "OPEN"
                })
                print(f"Created ServiceNow Incident: {incident_id}")
        else:
            print(f"No threshold breach: {result_count} < {threshold}")

    return {"status": "done"}


def run_athena_query(query):
    """Execute Athena query and return result count (example assumes numeric result)."""
    response = athena.start_query_execution(
        QueryString=query,
        QueryExecutionContext={"Database": ATHENA_DB},
        ResultConfiguration={"OutputLocation": ATHENA_OUTPUT},
    )

    query_execution_id = response["QueryExecutionId"]

    # Wait for query to complete
    while True:
        status = athena.get_query_execution(QueryExecutionId=query_execution_id)
        state = status["QueryExecution"]["Status"]["State"]

        if state in ["SUCCEEDED", "FAILED", "CANCELLED"]:
            break
        time.sleep(2)

    if state != "SUCCEEDED":
        print(f"Athena query failed: {state}")
        return 0

    # Fetch results
    results = athena.get_query_results(QueryExecutionId=query_execution_id)
    rows = results["ResultSet"]["Rows"]

    if len(rows) > 1:
        # Assuming first row is header, second row has numeric value
        value = rows[1]["Data"][0].get("VarCharValue", "0")
        return int(value)
    return 0


def create_service_now_ticket(rule, result_count):
    """Create incident in ServiceNow via REST API"""
    payload = {
        "short_description": f"Threshold breach for rule {rule['rule_id']}",
        "description": f"Query: {rule['athena_query']} breached threshold {rule['threshold']} with value {result_count}.",
        "severity": rule.get("severity", "2"),
        "category": rule.get("category", "Infrastructure"),
    }

    try:
        response = requests.post(
            SERVICENOW_URL,
            auth=(SERVICENOW_USER, SERVICENOW_PASS),
            headers={"Content-Type": "application/json"},
            data=json.dumps(payload),
            timeout=30
        )
        response.raise_for_status()
        result = response.json()
        return result["result"]["sys_id"]
    except Exception as e:
        print(f"Failed to create ServiceNow ticket: {e}")
        return None
